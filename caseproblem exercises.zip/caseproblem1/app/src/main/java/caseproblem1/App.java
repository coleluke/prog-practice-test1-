import java.util.ArrayList;
import java.util.Comparator;
import java.util.Objects;
import java.util.Scanner;

public class Event {
    private int eventNumber;
    private int numberOfGuests;
    private double pricePerGuest;
    private String phoneNumber;
    private int eventType; // 0 - wedding, 1 - baptism, 2 - birthday, 3 - corporate, 4 - other
    private static final String[] EVENT_TYPES = {"Wedding", "Baptism", "Birthday", "Corporate", "Other"};

    public Event(int eventNumber, int numberOfGuests, double pricePerGuest, String phoneNumber, int eventType) {
        this.eventNumber = eventNumber;
        this.numberOfGuests = numberOfGuests;
        this.pricePerGuest = pricePerGuest;
        this.phoneNumber = phoneNumber;
        setEventType(eventType);
    }

    public int getEventNumber() {
        return eventNumber;
    }

    public void setEventNumber(int eventNumber) {
        this.eventNumber = eventNumber;
    }

    public int getNumberOfGuests() {
        return numberOfGuests;
    }

    public void setNumberOfGuests(int numberOfGuests) {
        this.numberOfGuests = numberOfGuests;
    }

    public double getPricePerGuest() {
        return pricePerGuest;
    }

    public void setPricePerGuest(double pricePerGuest) {
        this.pricePerGuest = pricePerGuest;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public int getEventType() {
        return eventType;
    }

    public void setEventType(int eventType) {
        if (eventType < 0 || eventType >= EVENT_TYPES.length) {
            this.eventType = EVENT_TYPES.length - 1; // set to "Other"
        } else {
            this.eventType = eventType;
        }
    }

    public String getEventTypeString() {
        return EVENT_TYPES[eventType];
    }

    public double getTotalPrice() {
        return numberOfGuests * pricePerGuest;
    }

    @Override
    public String toString() {
        return "Event Number: " + eventNumber + ", Guests: " + numberOfGuests +
                ", Price per Guest: $" + pricePerGuest + ", Total Price: $" + getTotalPrice() +
                ", Phone: " + phoneNumber + ", Event Type: " + getEventTypeString();
    }
}

public class EventDemo {
    public static void Main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Event[] events = new Event[8];

        // Get data for Event objects
        for (int i = 0; i < events.length; i++) {
            System.out.println("Enter details for Event " + (i + 1) + ":");
            System.out.print("Event Number: ");
            int eventNumber = scanner.nextInt();
            System.out.print("Number of Guests: ");
            int numberOfGuests = scanner.nextInt();
            System.out.print("Price per Guest: ");
            double pricePerGuest = scanner.nextDouble();
            System.out.print("Phone Number: ");
            String phoneNumber = scanner.next();
            System.out.print("Event Type (0 - Wedding, 1 - Baptism, 2 - Birthday, 3 - Corporate, 4 - Other): ");
            int eventType = scanner.nextInt();

            events[i] = new Event(eventNumber, numberOfGuests, pricePerGuest, phoneNumber, eventType);
        }

        while (true) {
            System.out.println("\nChoose a sorting option: ");
            System.out.println("1. Sort by Event Number");
            System.out.println("2. Sort by Number of Guests");
            System.out.println("3. Sort by Event Type");
            System.out.println("Enter 0 to exit.");
            int choice = scanner.nextInt();

            if (choice == 0) {
                break;
            }

            switch (choice) {
                case 1:
                    ArrayList<> Arrays;
                    Arrays.sort(events,Main(Event::getEventNumber));
                    break;
                case 2:
                    Arrays.sort(events,Main(Event::getNumberOfGuests));
                    break;
                case 3:
                    Arrays.sort(events, Comparator.comparing(Event::getEventTypeString));
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
                    continue;
            }

            System.out.println("Sorted Events:");
            for (Event event : events) {
                System.out.println(event);
            }
        }
        scanner.close();
    }
}
