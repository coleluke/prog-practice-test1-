import java.util.ArrayList;
import java.util.List;

public class Card {
    private String suit;
    private String value;

    public Card(String suit, String value) {
        this.suit = suit;
        this.value = value;
    }

    public String getSuit() {
        return suit;
    }

    public String getValue() {
        return value;
    }

    @Override
    public String toString() {
        return value + " of " + suit;
    }
}


public class War3 {
    public static void main(String[] args) {
        String[] suits = {"Spades", "Hearts", "Diamonds", "Clubs"};
        String[] values = {"Ace", "2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King"};
        List<Card> deck = new ArrayList<>();

        // Create a deck of 52 cards
        for (String suit : suits) {
            for (String value : values) {
                deck.add(new Card(suit, value));
            }
        }

        int playerWins = 0;
        int computerWins = 0;
        int ties = 0;
        Random rand = new Random();

        // Play 26 rounds
        for (int round = 0; round < 26; round++) {
            int playerIndex = rand.nextInt(deck.size());
            Card playerCard = deck.remove(playerIndex);

            int computerIndex = rand.nextInt(deck.size());
            Card computerCard = deck.remove(computerIndex);

            System.out.println("Player plays: " + playerCard);
            System.out.println("Computer plays: " + computerCard);

            int playerValue = getCardValue(playerCard);
            int computerValue = getCardValue(computerCard);

            if (playerValue > computerValue) {
                System.out.println("Player wins this round!\n");
                playerWins++;
            } else if (computerValue > playerValue) {
                System.out.println("Computer wins this round!\n");
                computerWins++;
            } else {
                System.out.println("It's a tie!\n");
                ties++;
            }
        }

        // Display results
        System.out.println("Final Results:");
        System.out.println("Player wins: " + playerWins);
        System.out.println("Computer wins: " + computerWins);
        System.out.println("Ties: " + ties);
    }

    private static int getCardValue(Card card) {
        String value = card.getValue();
        switch (value) {
            case "Ace": return 14;
            case "King": return 13;
            case "Queen": return 12;
            case "Jack": return 11;
            default: return Integer.parseInt(value); // for numbered cards
        }
    }
}
import java.util.ArrayList;
import java.util.List;

public class FullDeck {
    public static void main(String[] args) {
        String[] suits = {"Spades", "Hearts", "Diamonds", "Clubs"};
        String[] values = {"Ace", "2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King"};
        List<Card> deck = new ArrayList<>();

        // Create a deck of 52 cards
        for (String suit : suits) {
            for (String value : values) {
                deck.add(new Card(suit, value));
            }
        }

        // Display each card in the deck
        for (Card card : deck) {
            System.out.println(card);
        }
    }
}
