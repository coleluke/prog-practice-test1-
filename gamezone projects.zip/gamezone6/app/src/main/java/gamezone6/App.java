import java.util.Scanner;

public class DoesItHaveLegs {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String animal = "dog"; // Initial guess
        String question = "Does it have legs?"; // Initial question

        System.out.println("Think of an animal, and I will try to guess it!");

        while (true) {
            System.out.println(question);
            String answer = scanner.nextLine().toLowerCase();

            if (answer.equals("yes")) {
                System.out.println("Is it a " + animal + "?");
                answer = scanner.nextLine().toLowerCase();

                if (answer.equals("yes")) {
                    System.out.println("Yay! I guessed it!");
                } else {
                    System.out.println("I give up! What animal were you thinking of?");
                    String newAnimal = scanner.nextLine();
                    System.out.println("What question would distinguish a " + newAnimal + " from a " + animal + "?");
                    String newQuestion = scanner.nextLine();
                    System.out.println("What is the answer for " + newAnimal + "? (yes/no)");
                    String newAnswer = scanner.nextLine().toLowerCase();

                    // Update the game with the new information
                    animal = newAnimal;
                    question = newQuestion;
                    System.out.println("Thanks for teaching me!");
                }
            } else {
                System.out.println("What animal are you thinking of?");
                animal = scanner.nextLine();
                question = "Does it have legs?"; // Reset question
            }
        }
    }
}


