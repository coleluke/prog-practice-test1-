import java.util.Random;
import java.util.Scanner;

public class Magic8Ball {
    public static void main(String[] args) {
        String[] responses = {
                "It is certain",
                "Yes, definitely",
                "You may rely on it",
                "As I see it, yes",
                "Most likely",
                "Outlook good",
                "Yes",
                "Definitely not",
                "My reply is no",
                "Don't count on it",
                "My sources say no",
                "Outlook not so good",
                "Yes, in due time",
                "Very doubtful",
                "Absolutely",
                "Ask again later",
                "Cannot predict now",
                "Yes, but not today",
                "I wouldn't count on it",
                "You can count on it",
                "Not a chance"
        };

        Scanner scanner = new Scanner(System.in);
        Random rand = new Random();
        String question;

        System.out.println("Welcome to the Magic 8 Ball!");
        System.out.println("Type your question and press Enter (type 'exit' to quit):");

        while (true) {
            question = scanner.nextLine();
            if (question.equalsIgnoreCase("exit")) {
                break;
            }

            int randomIndex = rand.nextInt(responses.length);
            System.out.println("Magic 8 Ball says: " + responses[randomIndex]);
        }

        System.out.println("Thank you for playing!");
        scanner.close();
    }
}
