import java.util.Random;
import java.util.Scanner;

public class SecretPhrase2 {
    public static void main(String[] args) {
        String[] phrases = {
                "No man is an island",
                "A picture is worth a thousand words",
                "The early bird catches the worm",
                "When in Rome, do as the Romans",
                "Actions speak louder than words",
                "Beggars can't be choosers",
                "A watched pot never boils",
                "Better late than never",
                "Practice makes perfect",
                "The pen is mightier than the sword"
        };

        Random rand = new Random();
        String phraseToGuess = phrases[rand.nextInt(phrases.length)];
        StringBuilder clue = new StringBuilder();

        for (char c : phraseToGuess.toCharArray()) {
            if (c == ' ') {
                clue.append(' ');
            } else {
                clue.append('*');
            }
        }

        Scanner scanner = new Scanner(System.in);
        int attempts = 6; // Number of incorrect guesses allowed

        while (attempts > 0 && clue.toString().contains("*")) {
            System.out.println("Phrase: " + clue);
            System.out.println("Attempts remaining: " + attempts);
            System.out.print("Guess a letter: ");
            char guess = scanner.nextLine().toLowerCase().charAt(0);

            boolean correctGuess = false;
            StringBuilder updatedClue = new StringBuilder(clue.toString());

            for (int i = 0; i < phraseToGuess.length(); i++) {
                if (Character.toLowerCase(phraseToGuess.charAt(i)) == guess) {
                    updatedClue.setCharAt(i, phraseToGuess.charAt(i));
                    correctGuess = true;
                }
            }

            clue = updatedClue;

            if (!correctGuess) {
                attempts--;
                System.out.println("Incorrect guess!");
            }
        }

        if (clue.toString().contains("*")) {
            System.out.println("You lost! The phrase was: " + phraseToGuess);
        } else {
            System.out.println("Congratulations! You've guessed the phrase: " + phraseToGuess);
        }

        scanner.close();
    }
}
