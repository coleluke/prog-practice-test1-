import java.util.Scanner;
import java.util.Random;

public class TicTacToe {
    public static void main(String[] args) {
        char[][] board = {{'1', '2', '3'}, {'4', '5', '6'}, {'7', '8', '9'}};
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();

        while (true) {
            printBoard(board);
            playerMove(board, scanner);
            if (checkWinner(board, 'X')) {
                printBoard(board);
                System.out.println("Player X wins!");
                break;
            }
            if (isBoardFull(board)) {
                printBoard(board);
                System.out.println("It's a tie!");
                break;
            }

            computerMove(board, random);
            if (checkWinner(board, 'O')) {
                printBoard(board);
                System.out.println("Computer O wins!");
                break;
            }
            if (isBoardFull(board)) {
                printBoard(board);
                System.out.println("It's a tie!");
                break;
            }
        }
    }

    static void printBoard(char[][] board) {
        for (char[] row : board) {
            for (char cell : row) {
                System.out.print(cell + " ");
            }
            System.out.println();
        }
    }

    static void playerMove(char[][] board, Scanner scanner) {
        int choice;
        while (true) {
            System.out.print("Enter a position (1-9): ");
            choice = scanner.nextInt();
            if (choice >= 1 && choice <= 9 && board[(choice - 1) / 3][(choice - 1) % 3] != 'X' && board[(choice - 1) / 3][(choice - 1) % 3] != 'O') {
                board[(choice - 1) / 3][(choice - 1) % 3] = 'X';
                break;
            }
            System.out.println("Invalid move. Try again.");
        }
    }

    static void computerMove(char[][] board, Random random) {
        int choice;
        do {
            choice = random.nextInt(9) + 1;
        } while (board[(choice - 1) / 3][(choice - 1) % 3] == 'X' || board[(choice - 1) / 3][(choice - 1) % 3] == 'O');
        board[(choice - 1) / 3][(choice - 1) % 3] = 'O';
    }

    static boolean checkWinner(char[][] board, char symbol) {
        for (int i = 0; i < 3; i++) {
            if ((board[i][0] == symbol && board[i][1] == symbol && board[i][2] == symbol) ||
                    (board[0][i] == symbol && board[1][i] == symbol && board[2][i] == symbol)) {
                return true;
            }
        }
        return (board[0][0] == symbol && board[1][1] == symbol && board[2][2] == symbol) ||
                (board[0][2] == symbol && board[1][1] == symbol && board[2][0] == symbol);
    }

    static boolean isBoardFull(char[][] board) {
        for (char[] row : board) {
            for (char cell : row) {
                if (cell != 'X' && cell != 'O') {
                    return false;
                }
            }
        }
        return true;
    }
}


import java.util.Random;
import java.util.Scanner;

public class TicTacToe2 {
    public static void main(String[] args) {
        char[][] board = {{'1', '2', '3'}, {'4', '5', '6'}, {'7', '8', '9'}};
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();

        while (true) {
            printBoard(board);
            playerMove(board, scanner);
            if (checkWinner(board, 'X')) {
                printBoard(board);
                System.out.println("Player X wins!");
                break;
            }
            if (isBoardFull(board)) {
                printBoard(board);
                System.out.println("It's a tie!");
                break;
            }

            if (!computerMove(board, random)) {
                printBoard(board);
                System.out.println("Computer O wins!");
                break;
            }
        }
    }

    static void printBoard(char[][] board) {
        for (char[] row : board) {
            for (char cell : row) {
                System.out.print(cell + " ");
            }
            System.out.println();
        }
    }

    static void playerMove(char[][] board, Scanner scanner) {
        int choice;
        while (true) {
            System.out.print("Enter a position (1-9): ");
            choice = scanner.nextInt();
            if (choice >= 1 && choice <= 9 && board[(choice - 1) / 3][(choice - 1) % 3] != 'X' && board[(choice - 1) / 3][(choice - 1) % 3] != 'O') {
                board[(choice - 1) / 3][(choice - 1) % 3] = 'X';
                break;
            }
            System.out.println("Invalid move. Try again.");
        }
    }

    static boolean computerMove(char[][] board, Random random) {
        // Check for winning move
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (board[i][j] != 'X' && board[i][j] != 'O') {
                    board[i][j] = 'O';
                    if (checkWinner(board, 'O')) {
                        return true;
                    }
                    board[i][j] = (char) ('1' + (i * 3 + j)); // Reset
                }
            }
        }

        // Block player
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (board[i][j] != 'X' && board[i][j] != 'O') {
                    board[i][j] = 'X';
                    if (checkWinner(board, 'X')) {
                        board[i][j] = 'O';
                        return true; // Blocked
                    }
                    board[i][j] = (char) ('1' + (i * 3 + j)); // Reset
                }
            }
        }

        // Random move
        int choice;
        do {
            choice = random.nextInt(9) + 1;
        } while (board[(choice - 1) / 3][(choice - 1) % 3] == 'X' || board[(choice - 1) / 3][(choice - 1) % 3] == 'O');
        board[(choice - 1) / 3][(choice - 1) % 3] = 'O';
        return false; // Computer did not win
    }

    static boolean checkWinner(char[][] board, char symbol) {
        for (int i = 0; i < 3; i++) {
            if ((board[i][0] == symbol && board[i][1] == symbol && board[i][2] == symbol) ||
                    (board[0][i] == symbol && board[1][i] == symbol && board[2][i] == symbol)) {
                return true;
            }
        }
        return (board[0][0] == symbol && board[1][1] == symbol && board[2][2] == symbol) ||
                (board[0][2] == symbol && board[1][1] == symbol && board[2][0] == symbol);
    }

    static boolean isBoardFull(char[][] board) {
        for (char[] row : board) {
            for (char cell : row) {
                if (cell != 'X' && cell != 'O') {
                    return false;
                }
            }
        }
        return true;
    }
}
