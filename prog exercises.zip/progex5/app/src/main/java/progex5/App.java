// Salesperson.java
public class Salesperson {
    private int idNumber;
    private double annualSales;

    // Constructor
    public Salesperson(int idNumber, double annualSales) {
        this.idNumber = idNumber;
        this.annualSales = annualSales;
    }

    // Getter and Setter for ID Number
    public int getIdNumber() {
        return idNumber;
    }

    public void setIdNumber(int idNumber) {
        this.idNumber = idNumber;
    }

    // Getter and Setter for Annual Sales
    public double getAnnualSales() {
        return annualSales;
    }

    public void setAnnualSales(double annualSales) {
        this.annualSales = annualSales;
    }

    // toString method for displaying Salesperson information
    @Override
    public String toString() {
        return "Salesperson ID: " + idNumber + ", Annual Sales: $" + annualSales;
    }
}

// DemoSalesperson2.java
public class DemoSalesperson2 {
    public static void main(String[] args) {
        Salesperson[] salesPeople = new Salesperson[10];
        
        // Initialize the array with successive IDs and sales values
        for (int i = 0; i < salesPeople.length; i++) {
            int idNumber = 111 + i;
            double annualSales = 25000 + (i * 5000);
            salesPeople[i] = new Salesperson(idNumber, annualSales);
        }
        
        // Display the Salesperson objects
        System.out.println("Salesperson Records:");
        for (Salesperson sp : salesPeople) {
            System.out.println(sp);
        }
    }
}


// SalespersonSort.java
import java.util.Scanner;
import java.util.Arrays;
import java.util.Comparator;

public class SalespersonSort {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Salesperson[] salesPeople = new Salesperson[7];
        
        // Input Salesperson data
        for (int i = 0; i < salesPeople.length; i++) {
            System.out.println("Enter ID number for Salesperson " + (i + 1) + ": ");
            int idNumber = scanner.nextInt();
            System.out.println("Enter annual sales for Salesperson " + (i + 1) + ": ");
            double annualSales = scanner.nextDouble();
            salesPeople[i] = new Salesperson(idNumber, annualSales);
        }
        
        // Display sorted Salesperson data
        System.out.println("Display options:");
        System.out.println("1. Sort by ID number");
        System.out.println("2. Sort by sales value");
        int option = scanner.nextInt();
        
        if (option == 1) {
            Arrays.sort(salesPeople, Comparator.comparingInt(Salesperson::getIdNumber));
        } else if (option == 2) {
            Arrays.sort(salesPeople, Comparator.comparingDouble(Salesperson::getAnnualSales));
        } else {
            System.out.println("Invalid option.");
            scanner.close();
            return;
        }
        
        // Display the Salesperson objects
        System.out.println("Sorted Salesperson Records:");
        for (Salesperson sp : salesPeople) {
            System.out.println(sp);
        }
        
        scanner.close();
    }
}
// SalespersonDatabase.java
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Collections;

public class SalespersonDatabase {
    private static final int MAX_SIZE = 20;
    private static ArrayList<Salesperson> database = new ArrayList<>();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean running = true;

        while (running) {
            System.out.println("Options: ");
            System.out.println("1. Add record");
            System.out.println("2. Delete record");
            System.out.println("3. Change record");
            System.out.println("4. Display database");
            System.out.println("5. Exit");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1: // Add record
                    if (database.size() >= MAX_SIZE) {
                        System.out.println("Error: Database is full.");
                    } else {
                        System.out.println("Enter ID number: ");
                        int idNumber = scanner.nextInt();
                        scanner.nextLine(); // Consume newline

                        if (findSalespersonById(idNumber) != null) {
                            System.out.println("Error: ID number already exists.");
                        } else {
                            System.out.println("Enter sales value: ");
                            double salesValue = scanner.nextDouble();
                            scanner.nextLine(); // Consume newline
                            database.add(new Salesperson(idNumber, salesValue));
                        }
                    }
                    break;
                case 2: // Delete record
                    if (database.isEmpty()) {
                        System.out.println("Error: Database is empty.");
                    } else {
                        System.out.println("Enter ID number to delete: ");
                        int idNumber = scanner.nextInt();
                        scanner.nextLine(); // Consume newline

                        Salesperson sp = findSalespersonById(idNumber);
                        if (sp == null) {
                            System.out.println("Error: ID number does not exist.");
                        } else {
                            database.remove(sp);
                        }
                    }
                    break;
                case 3: // Change record
                    if (database.isEmpty()) {
                        System.out.println("Error: Database is empty.");
                    } else {
                        System.out.println("Enter ID number to change: ");
                        int idNumber = scanner.nextInt();
                        scanner.nextLine(); // Consume newline

                        Salesperson sp = findSalespersonById(idNumber);
                        if (sp == null) {
                            System.out.println("Error: ID number does not exist.");
                        } else {
                            System.out.println("Enter new sales value: ");
                            double newSalesValue = scanner.nextDouble();
                            scanner.nextLine(); // Consume newline
                            sp.setAnnualSales(newSalesValue);
                        }
                    }
                    break;
                case 4: // Display database
                    Collections.sort(database, (a, b) -> Integer.compare(a.getIdNumber(), b.getIdNumber()));
                    System.out.println("Salesperson Records:");
                    for (Salesperson sp : database) {
                        System.out.println(sp);
                    }
                    break;
                case 5: // Exit
                    running = false;
                    break;
                default:
                    System.out.println("Invalid option.");
                    break;
            }
        }

        scanner.close();
    }

    private static Salesperson findSalespersonById(int idNumber) {
        for (Salesperson sp : database) {
            if (sp.getIdNumber() == idNumber) {
                return sp;
            }
        }
        return null;
    }
}
