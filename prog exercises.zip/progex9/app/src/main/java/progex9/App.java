// Purchase.java
public class Purchase {
    private int invoiceNumber;
    private double saleAmount;
    private double salesTax;

    // Constructor
    public Purchase() {
        this.invoiceNumber = 0;
        this.saleAmount = 0.0;
        this.salesTax = 0.0;
    }

    // Setter for Invoice Number
    public void setInvoiceNumber(int invoiceNumber) {
        this.invoiceNumber = invoiceNumber;
    }

    // Setter for Sale Amount and Sales Tax Calculation
    public void setSaleAmount(double saleAmount) {
        this.saleAmount = saleAmount;
        this.salesTax = saleAmount * 0.05; // 5% sales tax
    }

    // Display Purchase Details
    public void display() {
        System.out.println("Invoice Number: " + invoiceNumber);
        System.out.println("Sale Amount: $" + saleAmount);
        System.out.println("Sales Tax: $" + salesTax);
    }
}


// PurchaseArray.java
import java.util.Scanner;

public class PurchaseArray {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Purchase[] purchases = new Purchase[5];

        for (int i = 0; i < purchases.length; i++) {
            purchases[i] = new Purchase();
            int invoiceNumber;
            double saleAmount;

            // Validate invoice number and sale amount
            while (true) {
                System.out.println("Enter invoice number (1000-8000): ");
                invoiceNumber = scanner.nextInt();
                if (invoiceNumber >= 1000 && invoiceNumber <= 8000) {
                    break;
                } else {
                    System.out.println("Invalid invoice number. Please enter a number between 1000 and 8000.");
                }
            }

            while (true) {
                System.out.println("Enter sale amount (non-negative): ");
                saleAmount = scanner.nextDouble();
                if (saleAmount >= 0) {
                    break;
                } else {
                    System.out.println("Invalid sale amount. Please enter a non-negative number.");
                }
            }
            
            scanner.nextLine(); // Consume newline
            purchases[i].setInvoiceNumber(invoiceNumber);
            purchases[i].setSaleAmount(saleAmount);
        }

        // Display all purchases
        System.out.println("Purchase Details:");
        for (Purchase purchase : purchases) {
            purchase.display();
            System.out.println();
        }

        scanner.close();
    }
}
