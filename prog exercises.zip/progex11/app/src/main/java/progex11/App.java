// StringSort.java
import java.util.Scanner;
import java.util.Arrays;

public class StringSort {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] strings = new String[15];
        int count = 0;

        System.out.println("Enter up to 15 strings. Type 'done' to finish early:");

        while (count < 15) {
            String input = scanner.nextLine();
            if (input.equalsIgnoreCase("done")) {
                break;
            }
            strings[count] = input;
            count++;
        }

        // Sort and display the strings
        Arrays.sort(strings, 0, count);

        System.out.println("Strings in ascending order:");
        for (int i = 0; i < count; i++) {
            System.out.println(strings[i]);
        }

        scanner.close();
    }
}
