// PhoneNumbers.java
import java.util.Scanner;

public class PhoneNumbers {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        String[] names = new String[30];
        String[] phoneNumbers = new String[30];
        
        // Initialize first 10 entries
        names[0] = "John";
        phoneNumbers[0] = "555-1234";
        names[1] = "Jane";
        phoneNumbers[1] = "555-5678";
        names[2] = "Alice";
        phoneNumbers[2] = "555-8765";
        names[3] = "Bob";
        phoneNumbers[3] = "555-4321";
        names[4] = "Carol";
        phoneNumbers[4] = "555-6789";
        names[5] = "Dave";
        phoneNumbers[5] = "555-3456";
        names[6] = "Eve";
        phoneNumbers[6] = "555-6543";
        names[7] = "Frank";
        phoneNumbers[7] = "555-9876";
        names[8] = "Grace";
        phoneNumbers[8] = "555-2345";
        names[9] = "Heidi";
        phoneNumbers[9] = "555-3457";
        
        int count = 10; // Number of entries initially in the directory
        
        while (true) {
            System.out.println("Enter a name (or 'quit' to exit): ");
            String inputName = scanner.nextLine();
            
            if (inputName.equalsIgnoreCase("quit")) {
                break;
            }
            
            // Search for the name in the directory
            boolean found = false;
            for (int i = 0; i < count; i++) {
                if (names[i].equalsIgnoreCase(inputName)) {
                    System.out.println("Phone number for " + inputName + ": " + phoneNumbers[i]);
                    found = true;
                    break;
                }
            }
            
            if (!found) {
                if (count >= 30) {
                    System.out.println("Directory is full. Cannot add more entries.");
                } else {
                    System.out.println("Name not found. Enter phone number: ");
                    String newPhoneNumber = scanner.nextLine();
                    names[count] = inputName;
                    phoneNumbers[count] = newPhoneNumber;
                    count++;
                    System.out.println("Entry added.");
                }
            }
        }
        
        scanner.close();
    }
}
