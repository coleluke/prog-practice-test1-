// Recording.java
public class Recording {
    private String title;
    private String artist;
    private int playingTime; // in seconds

    // Constructor
    public Recording(String title, String artist, int playingTime) {
        this.title = title;
        this.artist = artist;
        this.playingTime = playingTime;
    }

    // Getters and setters
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getArtist() {
        return artist;
    }

    public void setArtist(String artist) {
        this.artist = artist;
    }

    public int getPlayingTime() {
        return playingTime;
    }

    public void setPlayingTime(int playingTime) {
        this.playingTime = playingTime;
    }

    // Display method
    public void display() {
        System.out.println("Title: " + title);
        System.out.println("Artist: " + artist);
        System.out.println("Playing Time: " + playingTime + " seconds");
    }
}


// RecordingSort.java
import java.util.Scanner;
import java.util.Arrays;
import java.util.Comparator;

public class RecordingSort {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Recording[] recordings = new Recording[5];

        // Input data for 5 recordings
        for (int i = 0; i < recordings.length; i++) {
            System.out.println("Enter details for Recording #" + (i + 1) + ":");
            System.out.print("Title: ");
            String title = scanner.nextLine();
            System.out.print("Artist: ");
            String artist = scanner.nextLine();
            System.out.print("Playing Time (in seconds): ");
            int playingTime = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            recordings[i] = new Recording(title, artist, playingTime);
        }

        // Choose sorting field
        System.out.println("Sort by: 1. Title 2. Artist 3. Playing Time");
        int choice = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        switch (choice) {
            case 1:
                Arrays.sort(recordings, Comparator.comparing(Recording::getTitle));
                break;
            case 2:
                Arrays.sort(recordings, Comparator.comparing(Recording::getArtist));
                break;
            case 3:
                Arrays.sort(recordings, Comparator.comparingInt(Recording::getPlayingTime));
                break;
            default:
                System.out.println("Invalid choice. Sorting by title.");
                Arrays.sort(recordings, Comparator.comparing(Recording::getTitle));
                break;
        }

        // Display sorted recordings
        System.out.println("Sorted Recordings:");
        for (Recording recording : recordings) {
            recording.display();
            System.out.println();
        }

        scanner.close();
    }
}
