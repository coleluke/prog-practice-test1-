// MeanMedian.java
import java.util.Scanner;
import java.util.Arrays;

public class MeanMedian {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int[] numbers = new int[9];
        int numCount = 0;

        System.out.println("Enter 9 integers:");

        // Read 9 integers
        while (numCount < 9) {
            numbers[numCount] = scanner.nextInt();
            numCount++;
        }

        // Sort the array
        Arrays.sort(numbers);

        // Calculate mean
        int sum = 0;
        for (int num : numbers) {
            sum += num;
        }
        double mean = (double) sum / numbers.length;

        // Calculate median
        double median;
        if (numbers.length % 2 == 0) {
            median = (numbers[numbers.length / 2 - 1] + numbers[numbers.length / 2]) / 2.0;
        } else {
            median = numbers[numbers.length / 2];
        }

        // Display results
        System.out.println("Values:");
        for (int num : numbers) {
            System.out.println(num);
        }
        System.out.println("Mean: " + mean);
        System.out.println("Median: " + median);

        scanner.close();
    }

// MeanMedian2.java
import java.util.Scanner;
import java.util.Arrays;

public class MeanMedian2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int[] numbers = new int[20];
        int numCount = 0;

        System.out.println("Enter up to 20 integers. Type 'done' to finish early:");

        // Read integers
        while (numCount < 20) {
            String input = scanner.nextLine();
            if (input.equalsIgnoreCase("done")) {
                break;
            }
            try {
                numbers[numCount] = Integer.parseInt(input);
                numCount++;
            } catch (NumberFormatException e) {
                System.out.println("Invalid input, please enter an integer.");
            }
        }

        // Sort the array
        Arrays.sort(numbers, 0, numCount);

        // Calculate mean
        int sum = 0;
        for (int i = 0; i < numCount; i++) {
            sum += numbers[i];
        }
        double mean = (double) sum / numCount;

        // Calculate median
        double median;
        if (numCount % 2 == 0) {
            median = (numbers[numCount / 2 - 1] + numbers[numCount / 2]) / 2.0;
        } else {
            median = numbers[numCount / 2];
        }

        // Display results
        System.out.println("Values:");
        for (int i = 0; i < numCount; i++) {
            System.out.println(numbers[i]);
        }
        System.out.println("Mean: " + mean);
        System.out.println("Median: " + median);

        scanner.close();
    }
}
