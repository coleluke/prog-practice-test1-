// CollegeCourse.java
public class CollegeCourse {
    private String courseId;
    private int creditHours;
    private char letterGrade;

    // Constructor
    public CollegeCourse(String courseId, int creditHours, char letterGrade) {
        this.courseId = courseId;
        this.creditHours = creditHours;
        this.letterGrade = letterGrade;
    }

    // Getter and Setter for Course ID
    public String getCourseId() {
        return courseId;
    }

    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }

    // Getter and Setter for Credit Hours
    public int getCreditHours() {
        return creditHours;
    }

    public void setCreditHours(int creditHours) {
        this.creditHours = creditHours;
    }

    // Getter and Setter for Letter Grade
    public char getLetterGrade() {
        return letterGrade;
    }

    public void setLetterGrade(char letterGrade) {
        this.letterGrade = letterGrade;
    }

    @Override
    public String toString() {
        return "Course ID: " + courseId + ", Credit Hours: " + creditHours + ", Grade: " + letterGrade;
    }
}

// Student.java
public class Student {
    private int idNumber;
    private CollegeCourse[] courses;

    // Constructor
    public Student(int idNumber) {
        this.idNumber = idNumber;
        this.courses = new CollegeCourse[5];
    }

    // Getter and Setter for ID Number
    public int getIdNumber() {
        return idNumber;
    }

    public void setIdNumber(int idNumber) {
        this.idNumber = idNumber;
    }

    // Getter for a specific CollegeCourse
    public CollegeCourse getCourse(int index) {
        if (index >= 0 && index < courses.length) {
            return courses[index];
        } else {
            return null; // or throw an exception
        }
    }

    // Setter for a specific CollegeCourse
    public void setCourse(CollegeCourse course, int index) {
        if (index >= 0 && index < courses.length) {
            courses[index] = course;
        }
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("Student ID: " + idNumber + "\n");
        for (int i = 0; i < courses.length; i++) {
            sb.append("Course " + (i + 1) + ": " + courses[i] + "\n");
        }
        return sb.toString();
    }
}

// InputGrades.java
import java.util.Scanner;

public class InputGrades {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Student[] students = new Student[10];
        final int COURSE_COUNT = 5;

        for (int i = 0; i < students.length; i++) {
            System.out.println("Enter ID for student #" + (i + 1) + ": ");
            int studentId = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            students[i] = new Student(studentId);

            for (int j = 0; j < COURSE_COUNT; j++) {
                System.out.println("Enter course ID #" + (j + 1) + ": ");
                String courseId = scanner.nextLine();
                System.out.println("Enter credit hours for course #" + (j + 1) + ": ");
                int creditHours = scanner.nextInt();
                scanner.nextLine(); // Consume newline

                char grade;
                while (true) {
                    System.out.println("Enter grade for course #" + (j + 1) + " (A, B, C, D, F): ");
                    grade = scanner.nextLine().toUpperCase().charAt(0);
                    if (grade == 'A' || grade == 'B' || grade == 'C' || grade == 'D' || grade == 'F') {
                        break;
                    } else {
                        System.out.println("Invalid grade. Please enter A, B, C, D, or F.");
                    }
                }

                CollegeCourse course = new CollegeCourse(courseId, creditHours, grade);
                students[i].setCourse(course, j);
            }
        }

        // Display all students and their courses
        System.out.println("Student Records:");
        for (Student student : students) {
            System.out.println(student);
        }

        scanner.close();
    }
}
