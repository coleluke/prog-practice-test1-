// TimesAndInstructors.java
import java.util.Scanner;

public class TimesAndInstructors {
    public static void main(String[] args) {
        // Define the courses, times, and instructors
        String[][] courses = {
            {"CIS101", "Mon 9 am", "Khan"},
            {"CIS202", "Tue 10 am", "Smith"},
            {"CIS101", "Wed 11 am", "Khan"},
            {"CIS303", "Thu 2 pm", "Lee"},
            {"CIS404", "Fri 3 pm", "O'Connor"}
        };

        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the course name: ");
        String courseName = scanner.nextLine();

        boolean found = false;

        // Search for the course
        for (String[] course : courses) {
            if (course[0].equalsIgnoreCase(courseName)) {
                System.out.println("Course: " + course[0]);
                System.out.println("Time: " + course[1]);
                System.out.println("Instructor: " + course[2]);
                System.out.println();
                found = true;
            }
        }

        if (!found) {
            System.out.println("Error: Course not found.");
        }

        scanner.close();
    }
}
