// Planets.java
import java.util.Scanner;

public class Planets {
    // Define enumeration for planets
    enum Planet {
        MERCURY, VENUS, EARTH, MARS, JUPITER, SATURN, URANUS, NEPTUNE
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Prompt user for a planet name
        System.out.print("Enter the name of a planet: ");
        String input = scanner.nextLine().toUpperCase();

        try {
            Planet planet = Planet.valueOf(input);
            int position = planet.ordinal() + 1; // ordinal() is zero-based
            System.out.println("The position of " + planet + " is: " + position);
        } catch (IllegalArgumentException e) {
            System.out.println("Invalid planet name entered.");
        }

        scanner.close();
    }
}
