// BirthdayReminder.java
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class BirthdayReminder {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Map<String, String> friends = new HashMap<>();
        final int MAX_FRIENDS = 10;

        // Input friends' names and birthdates
        while (friends.size() < MAX_FRIENDS) {
            System.out.println("Enter name (or ZZZ to stop): ");
            String name = scanner.nextLine();
            if (name.equalsIgnoreCase("ZZZ")) {
                break;
            }
            System.out.println("Enter birthdate (e.g., MM/DD/YYYY): ");
            String birthdate = scanner.nextLine();
            friends.put(name, birthdate);
        }

        // Display the number of names entered and the names
        System.out.println("Number of names entered: " + friends.size());
        System.out.println("Names entered:");
        for (String name : friends.keySet()) {
            System.out.println(name);
        }

        // Look up birthdates
        while (true) {
            System.out.println("Enter a name to get the birthdate (or type '722' to exit): ");
            String nameToLookup = scanner.nextLine();
            if (nameToLookup.equals("722")) {
                break;
            }
            if (friends.containsKey(nameToLookup)) {
                System.out.println("Birthdate for " + nameToLookup + ": " + friends.get(nameToLookup));
            } else {
                System.out.println("Error: Name not found.");
            }
        }

        scanner.close();
    }
}
