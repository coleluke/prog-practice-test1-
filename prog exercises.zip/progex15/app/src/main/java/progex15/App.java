// DayOfWeek.java
import java.util.Scanner;

public class DayOfWeek {
    // Define enumeration for days of the week
    enum Day {
        SUNDAY, MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Display list of days
        System.out.println("Days of the Week:");
        for (Day day : Day.values()) {
            System.out.println(day);
        }

        // Prompt user for a day
        System.out.print("Enter a day: ");
        String input = scanner.nextLine().toUpperCase();
        Day selectedDay;

        try {
            selectedDay = Day.valueOf(input);
        } catch (IllegalArgumentException e) {
            System.out.println("Invalid day entered.");
            scanner.close();
            return;
        }

        // Display business hours
        switch (selectedDay) {
            case SUNDAY:
                System.out.println("Business hours: 11 am to 5 pm");
                break;
            case MONDAY:
            case TUESDAY:
            case WEDNESDAY:
            case THURSDAY:
            case FRIDAY:
                System.out.println("Business hours: 9 am to 9 pm");
                break;
            case SATURDAY:
                System.out.println("Business hours: 10 am to 6 pm");
                break;
        }

        scanner.close();
    }
}
