import java.util.Scanner;

public class Main {
    public static void Main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int[] numbers = new int[10];

        System.out.println("Enter 10 integers:");
        for (int i = 0; i < 10; i++) {
            numbers[i] = scanner.nextInt();
        }

        displayNumbers(numbers);
        displayNumbersReverse(numbers);
        displaySum(numbers);
        displayLessThan12(numbers);
        displayGreaterThanAverage(numbers);

        scanner.close();
    }

    public static void displayNumbers(int[] array) {
        System.out.println("Numbers:");
        for (int num : array) {
            System.out.print(num + " ");
        }
        System.out.println();
    }

    public static void displayNumbersReverse(int[] array) {
        System.out.println("Numbers in reverse:");
        for (int i = array.length - 1; i >= 0; i--) {
            System.out.print(array[i] + " ");
        }
        System.out.println();
    }

    public static void displaySum(int[] array) {
        int sum = 0;
        for (int num : array) {
            sum += num;
        }
        System.out.println("Sum: " + sum);
    }

    public static void displayLessThan12(int[] array) {
        boolean found = false;
        System.out.println("Values less than 12:");
        for (int num : array) {
            if (num < 12) {
                System.out.print(num + " ");
                found = true;
            }
        }
        if (!found) {
            System.out.println("No values less than 12.");
        }
        System.out.println();
    }

    public static void displayGreaterThanAverage(int[] array) {
        double sum = 0;
        for (int num : array) {
            sum += num;
        }
        double average = sum / array.length;
        System.out.println("Values greater than average (" + average + "):");
        boolean found = false;
        for (int num : array) {
            if (num > average) {
                System.out.print(num + " ");
                found = true;
            }
        }
        if (!found) {
            System.out.println("No values greater than the average.");
        }
        System.out.println();
    }
}
