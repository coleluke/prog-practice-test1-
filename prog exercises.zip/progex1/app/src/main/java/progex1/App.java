public class Main {
    public static void Main(String[] args) {
        // Declare and initialize the array
        int[] numbers = {10, 20, 30, 40, 50, 60, 70, 80, 90};

        // Display integers from first to last
        System.out.println("Numbers from first to last:");
        for (int num : numbers) {
            System.out.print(num + " ");
        }
        System.out.println();

        // Display integers from last to first
        System.out.println("Numbers from last to first:");
        for (int i = numbers.length - 1; i >= 0; i--) {
            System.out.print(numbers[i] + " ");
        }
        System.out.println();
    }
}
