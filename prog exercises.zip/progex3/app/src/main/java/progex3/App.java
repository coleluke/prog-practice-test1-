import java.util.Scanner;

public class Main {
    public static void Main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Choose a service: oil change, tire rotation, battery check, brake inspection");

        String choice = scanner.nextLine().trim().toLowerCase();
        switch (choice) {
            case "oil change":
                System.out.println("Oil change: $25");
                break;
            case "tire rotation":
                System.out.println("Tire rotation: $22");
                break;
            case "battery check":
                System.out.println("Battery check: $15");
                break;
            case "brake inspection":
                System.out.println("Brake inspection: $5");
                break;
            default:
                System.out.println("Error: Invalid service choice.");
                break;
        }

    }
}


import java.util.Scanner;

public class Main{
    public static void Main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Choose a service: oil change, tire rotation, battery check, brake inspection");

        String choice = scanner.nextLine().trim().toLowerCase();
        String service;

        switch (choice.substring(0, Math.min(choice.length(), 3))) {
            case "oil":
                service = "Oil change";
                System.out.println("Oil change: $25");
                break;
            case "tir":
                service = "Tire rotation";
                System.out.println("Tire rotation: $22");
                break;
            case "bat":
                service = "Battery check";
                System.out.println("Battery check: $15");
                break;
            case "bra":
                service = "Brake inspection";
                System.out.println("Brake inspection: $5");
                break;
            default:
                System.out.println("Error: Invalid service choice.");
                break;
        }

        scanner.close();
    }
}
