import java.util.Scanner;
public class Main {
    public static void Main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double[] numbers = new double[15];
        int count = 0;
        double sum = 0;

        System.out.println("Enter up to 15 double values. Enter 99999 to quit:");

        while (count < 15) {
            double input = scanner.nextDouble();
            if (input == 99999) break;
            numbers[count++] = input;
            sum += input;
        }

        if (count == 0) {
            System.out.println("Error: No numbers were entered.");
        } else {
            double average = sum / count;
            System.out.println("Count: " + count);
            System.out.println("Average: " + average);
            System.out.println("Value and Distance from Average:");

            for (int i = 0; i < count; i++) {
                double distance = Math.abs(numbers[i] - average);
                System.out.printf("%.2f: %.2f%n", numbers[i], distance);
            }
        }

        scanner.close();
    }
}
