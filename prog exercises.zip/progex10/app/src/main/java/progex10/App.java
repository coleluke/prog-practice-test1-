// DrugTests2.java
import java.util.Random;

public class DrugTests2 {
    public static void main(String[] args) {
        final int TOTAL_EMPLOYEES = 30;
        final int WEEKS = 52;
        int[] selectionCount = new int[TOTAL_EMPLOYEES];
        Random random = new Random();

        for (int week = 0; week < WEEKS; week++) {
            int employeeNumber = random.nextInt(TOTAL_EMPLOYEES) + 1;
            selectionCount[employeeNumber - 1]++;
            if (week % 4 == 0) { // Display 4 employee numbers per line
                System.out.println();
            }
            System.out.print(employeeNumber + " ");
        }

        System.out.println("\n\nEmployee Selection Count:");
        for (int i = 0; i < selectionCount.length; i++) {
            System.out.println("Employee " + (i + 1) + ": " + selectionCount[i] + " times");
        }

        System.out.println("\nEmployees not selected:");
        for (int i = 0; i < selectionCount.length; i++) {
            if (selectionCount[i] == 0) {
                System.out.println("Employee " + (i + 1));
            }
        }
    }
}


// DrugTests3.java
import java.util.Random;

public class DrugTests3 {
    public static void main(String[] args) {
        final int TOTAL_EMPLOYEES = 30;
        final int WEEKS = 52;
        int[] selectionCount = new int[TOTAL_EMPLOYEES];
        Random random = new Random();
        int lastSelected = -1;

        for (int week = 0; week < WEEKS; week++) {
            int employeeNumber;
            do {
                employeeNumber = random.nextInt(TOTAL_EMPLOYEES) + 1;
                if (employeeNumber == lastSelected) {
                    System.out.println("Employee " + lastSelected + " was selected last week. Selecting a new number.");
                }
            } while (employeeNumber == lastSelected);

            selectionCount[employeeNumber - 1]++;
            lastSelected = employeeNumber;

            if (week % 4 == 0) { // Display 4 employee numbers per line
                System.out.println();
            }
            System.out.print(employeeNumber + " ");
        }

        System.out.println("\n\nEmployee Selection Count:");
        for (int i = 0; i < selectionCount.length; i++) {
            System.out.println("Employee " + (i + 1) + ": " + selectionCount[i] + " times");
        }

        System.out.println("\nEmployees not selected:");
        for (int i = 0; i < selectionCount.length; i++) {
            if (selectionCount[i] == 0) {
                System.out.println("Employee " + (i + 1));
            }
        }
    }
}
